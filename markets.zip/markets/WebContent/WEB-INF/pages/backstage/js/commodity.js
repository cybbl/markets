var startPage = 1;
var pages = 0; 
$(function(){
    $('.menu').on('click', '.commodity', function() {
        var $commodity = $(this);
        $.ajax({
            type: "POST",
            url:"http://localhost:8080/markets/getGoodsList",
            data:"&startPage=" + startPage + "&pageSize=8",
            success: function(msg) {
                commodityList(msg);
            }
          });
    })

    $(document).on('click', '#goods_search', function(event) {
        var goods_name = $("#goods_name").val();
            // 根据用户名获取用户列表
            $.ajax({
              type: "POST",
              url: "http://localhost:8080/markets/findGoodsByName",
              data: "name=" + goods_name,
              success: function(msg) {
                commodityList(msg);
              }
            });
      });

      $(document).on('click', '#add', function() {
        var modal = document.getElementById("modal");
        var closeBtn = document.getElementsByClassName("close")[0];
        modal.style.display = "block";
        document.body.classList.add("modal-open");
        closeBtn.onclick = function(){
            modal.style.display = "none";
        }
        
        var confirmBtn = document.getElementsByClassName("confirmBtn")[0];
        confirmBtn.onclick=function(){
            var goods_id = $("#goods_id").val();
            var goods_name = $("#goods_names").val();
            console.log(goods_name);
            var cat_id = $("#cat_id").val();
            var image1 = $("#image1").val();
            var image2 = $("#image2").val();
            var image3 = $("#image3").val();
            var image4 = $("#image4").val();
            var image5 = $("#image5").val();
            var goods_price = $("#goods_price").val();
            var goods_number = $("#goods_number").val();
            var goods_introduce = $("#goods_introduce").val();
            $.ajax({
                url: "http://localhost:8080/markets/saveGoods",
                type: "POST",
                data: {
                  goods_id: goods_id,
                  goods_name: goods_name,
                  cat_id: cat_id,
                  image1: image1,
                  image2: image2,
                  image3: image3,
                  image4: image4,
                  image5: image5,
                  goods_price: goods_price,
                  goods_number: goods_number,
                  goods_introduce: goods_introduce
                },
                success: function(response) {
                  // 处理成功响应
                  alert("新增成功");
                },
              });
        }
      });
})

  
function commodityList(msg){
    var html="";
    try {
        html = "<div class='list-content'>";
        html += "  <!--块元素-->";
        html += "  <div class='block'>";
        html += "    <!--页面有多个表格时，可以用于标识表格-->";
        html += "    <h2>商品信息管理</h2>";
        html += "    <!--正文内容-->";
        html += "    <div class='main'>";
        html += "      <!--表格上方的操作元素，添加、删除等-->";
        html += "      <div class='operation-wrap'>";
        html += "        <div class='buttons-wrap'>";
        html += "          <button id='add' class='button blue radius-3'><span class='icon-plus'></span> 添加</button>";
        html += "          <div class='input-group'>";
        html += "            <input id='goods_name' type='text' class='text' placeholder='输入商品名'>";
        html += "            <button id='goods_search' class='button blue'>搜索</button>";
        html += "          </div>";
        html += "        </div>";
        html += "      </div>";
        html += "      <table id='table' class='table color2'>";
        html += "        <thead>";
        html += "          <tr>";
        html += "            <th>商品id</th>";
        html += "            <th>商品名称</th>";
        html += "            <th>商品图片1</th>";
        html += "            <th>商品图片2</th>";
        html += "            <th>商品图片3</th>";
        html += "            <th>商品图片4</th>";
        html += "            <th>商品图片5</th>";
        html += "            <th>单价</th>";
        html += "            <th>库存</th>";
        html += "            <th>简介</th>";
        html += "          </tr>";
        html += "        </thead>";
        html += "        <tbody>";
        for(var i =0;i<msg.data.length;i++){
        html += "            <tr>";
        html += "              <td><div class='text'>"+msg.data[i].goods_id+"</div></td>";
        html += "              <td><div style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>"+msg.data[i].goods_name+"</div></td>";
        html += "              <td><div style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>"+msg.data[i].image1+"</div></td>";
        html += "              <td><div style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>"+msg.data[i].image2+"</div></td>";
        html += "              <td><div style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>"+msg.data[i].image3+"</div></td>";
        html += "              <td><div style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>"+msg.data[i].image4+"</div></td>";
        html += "              <td><div style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>"+msg.data[i].image5+"</div></td>";
        html += "              <td><div style='width: 50px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>"+msg.data[i].goods_price+"</div></td>";
        html += "              <td><div style='width: 50px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>"+msg.data[i].goods_number+"</div></td>";
        html += "              <td><div style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>"+msg.data[i].goods_introduce+"</div></td>";
        html += "            </tr>";
        }
        html += "        </tbody>";
        html += "      </table>";
        html += "    </div>";
        html += "  </div>";
        html += "</div>";

    } catch (error) {}
    $(".admin-markdown").html(html);
}