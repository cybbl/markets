var startPage = 1;
var pages = 0; 
$(function(){
    $('.menu').on('click', '.order', function() {
        var $order = $(this);
        $.ajax({
            type: "POST",
            url:"http://localhost:8080/markets/findOrder",
            data:"&startPage=" + startPage + "&pageSize=10",
            success: function(msg) {
                orderList(msg);
            }
          });
    })

    $(document).on('click', '#ordersearch', function(event) {
        var order_num = $("#order_num").val();
        var realName = $("#realName").val();
        if(order_num==""||realName==""){
            alert("请输入完整信息");
        }else{
            $.ajax({
                type: "POST",
                url: "http://localhost:8080/markets/findOrderByNumberAndName",
                data: "order_num=" + order_num+"&realName="+realName,
                success: function(msg) {
                    orderList(msg);
                }
              });
        }
      });
})

function orderList(msg){
    var html="";
    try {
        var html = "<div class='list-content'>";
            html += "  <!--块元素-->";
            html += "  <div class='block'>";
            html += "    <!--页面有多个表格时，可以用于标识表格-->";
            html += "    <h2>商品信息管理</h2>";
            html += "    <!--正文内容-->";
            html += "    <div class='main'>";
            html += "      <!--表格上方的操作元素，添加、删除等-->";
            html += "      <div class='operation-wrap'>";
            html += "        <div class='buttons-wrap'>";
            // html += "          <button id='send' class='button green radius-3'><span class=''></span> 发货</button>";
            // html += "          <button id='delete' class='button red radius-3'><span class='icon-close2'></span> 删除</button>";
            html += "          <!--表格上方的搜索操作-->";
            html += "          <div class='input-group'>";
            html += "            <input id='order_num' type='text' class='text' placeholder='输入订单号'>";
            html += "            <input id='realName' type='text' class='text' placeholder='输入收货人'>";
            html += "            <button id='ordersearch' class='button blue'>搜索</button>";
            html += "          </div>";
            html += "        </div>";
            html += "      </div>";
            html += "      <table id='table' class='table color2'>";
            html += "        <thead>";
            html += "          <tr>";
            html += "            <th>订单号</th>";
            html += "            <th>商品名称</th>";
            html += "            <th>商品数量</th>";
            html += "            <th>订单金额</th>";
            html += "            <th>订单状态</th>";
            html += "            <th>创建时间</th>";
            html += "            <th>收件人</th>";
            html += "            <th>收货地址</th>";
            html += "          </tr>";
            html += "        </thead>";
            html += "        <tbody>";
            for(var i =0;i<msg.data.length;i++){
                                    var status  = msg.data[i].order_status;
                                    var orderStatus= (status===1)?"待发货":"未付款";
            html += "            <tr>";
            html += "              <td><div class=''>"+msg.data[i].order_num+"</div></td>";
            html += "              <td><div class='text'>"+msg.data[i].goods_name+"</div></td>";
            html += "              <td><div class=''>"+msg.data[i].buy_counts+"</div></td>";
            html += "              <td><div class=''>"+msg.data[i].paid_amount+"</div></td>";
            html += "              <td><div class=''>"+orderStatus+"</div></td>";
            html += "              <td><div class=''>"+msg.data[i].create_time+"</div></td>";
            html += "              <td><div class=''>"+msg.data[i].realName+"</div></td>";
            html += "              <td><div class=''>"+msg.data[i].address+"</div></td>";
            html += "            </tr>";
            }
            html += "        </tbody>";
            html += "      </table>";
            html += "      </div>";
            html += "    </div>";
            html += "  </div>";
    } catch (error) {}
    $(".admin-markdown").html(html);
}