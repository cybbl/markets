$(function() {
    // 定义用户管理器点击事件处理程序
    $('.menu').on('click', '.userManager', function() {
      var $userManager = $(this);
      
      // 获取总数
      $.ajax({
        type: "POST",
        url: "http://localhost:8080/markets/findAllCount",
        data: "",
        success: function(total) {
          // 获取用户列表
          $.ajax({
            type: "POST",
            url: "http://localhost:8080/markets/findAll",
            data: "",
            success: function(msg) {
              userList(total, msg);
            }
          });
        }
      });
    });
  
    // 定义搜索按钮点击事件处理程序
    $(document).on('click', '#search', function(event) {
      var username = $("#username").val();
      // 根据用户名获取总数
      $.ajax({
        type: "POST",
        url: "http://localhost:8080/markets/findAllCountByUserName",
        data: "username=" + username,
        success: function(total) {
          // 根据用户名获取用户列表
          $.ajax({
            type: "POST",
            url: "http://localhost:8080/markets/findAllByUserName",
            data: "username=" + username,
            success: function(msg) {
              userList(total, msg);
            }
          });
        }
      });
    });
  });
  
  

function userList(total,msg){
    var html = "";
    try {
        html += "<div class='list-content'>";
        html += "  <!--块元素-->";
        html += "  <div class='block'>";
        html += "    <!--页面有多个表格时，可以用于标识表格-->";
        html += "    <h2>用户信息管理</h2>";
        html += "    <!--正文内容-->";
        html += "    <div class='main'>";
        html += "      <!--表格上方的操作元素，添加、删除等-->";
        html += "      <div class='operation-wrap'>";
        html += "        <div class='buttons-wrap'>";
        //html += "          <button id='delete' class='button red radius-3'><span class='icon-close2'></span> 删除</button>";
        html += "          <!--表格上方的搜索操作-->";
        html += "          <div class='input-group'>";
        html += "            <input id='username' type='text' class='text' placeholder='输入用户名搜索' />";
        html += "            <button id='search' class='button blue'>搜索</button>";
        html += "          </div>";
        html += "        </div>";
        html += "      </div>";

        html += "      <table id='table' class='table color2'>";
        html += "        <thead>";
        html += "          <tr>";
        html += "            <th class='checkbox'><input type='checkbox' class='fill listen-1' /> </th>";
        html += "            <th>用户id</th>";
        html += "            <th>用户名</th>";
        html += "            <th>密码</th>";
        html += "            <th>邮箱</th>";
        html += "            <th>电话</th>";
        html += "            <th>真实姓名</th>";
        html += "            <th>地址</th>";
        html += "          </tr>";
        html += "        </thead>";
        html += "        <tbody>";
        for(var i =0;i<total;i++){
        html += "          <tr>";
        html += "            <td class='checkbox'><input type='checkbox' class='fill listen-1-2 check' value='' /> </td>";
        html += "            <td>";
        html += "              <div class='text'>"+msg.data[i].user_id+"</div>";
        html += "            </td>";
        html += "            <td>";
        html += "              <div class='text'>"+msg.data[i].username+"</div>";
        html += "            </td>";
        html += "            <td>";
        html += "              <div class='text'>"+msg.data[i].password+"</div>";
        html += "            </td>";
        html += "            <td>";
        html += "              <div class='text'>"+msg.data[i].email+"</div>";
        html += "            </td>";
        html += "            <td>";
        html += "              <div class='text'>"+msg.data[i].phone+"</div>";
        html += "            </td>";
        html += "            <td>";
        html += "              <div class='text'>"+msg.data[i].realName+"</div>";
        html += "            </td>";
        html += "            <td>";
        html += "              <div class='text'>"+msg.data[i].address+"</div>";
        html += "            </td>";
        html += "          </tr>";
                                }
        html += "        </tbody>";
        html += "      </table>";
        html += "    </div>";
        html += "  </div>";
        html += "</div>";               
    } catch (error) {}
    $(".admin-markdown").html(html);
}