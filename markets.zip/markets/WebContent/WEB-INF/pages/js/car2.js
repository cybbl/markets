var user_id = 0;
//用来保存goods_Id
var goodsIds = [];
//购物车商品数量
var value = 0;
//用来保存用户选择的商品
var selectIds = [];
//用来保存被选商品的数量
var inputValue = [];
var goods_id = 0;
//购物车小计
var subtotal = 0;
$(function(){
//传user,左上角显示
  try {
    var strUser = localStorage.getItem("user");
    var json = JSON.parse(strUser);
    user_id = json.user_id;
    if(json!=null){
        $("#logintop").html(json.username);
        $("#registertop").html("退出登录");
    }    
} catch (error) {}
$("#registertop").click(function(){
    localStorage.setItem("user", "");
    location.href = "login.html";
})

//获取购物车商品种类数量
//两种商品，for循环的终止值就是2
// $.ajax({
//   type:"post",
//   url:"http://localhost:8080/markets/findCountByUserId",
//   data:"user_id="+user_id,
//   success:function(msg){
//       cartnum = msg;
//   }
// })

//获取购物车商品种类
//显示具体买了哪几种商品
$.ajax({
type:"post",
url:"http://localhost:8080/markets/findGoodsIdByUserId",
data:"user_id="+user_id,
dataType: 'json',
success:function(msg){
    var responseObj = msg.data;
    responseObj.forEach(function(item) {
        goodsIds.push(item.goods_id);
    //更新状态（第一次进入页面时，所有商品状态设置为0）
    // $.ajax({
    //   type: "POST",
    //   url: "http://localhost:8080/markets/updateCartStatue",
    //   data: {
    //     user_id: user_id,
    //     goods_id: goodsIds[i],
    //     isChecked: 1,
    //   }
    // });

    });
    //根据商品id和用户id获取商品信息
    var promises = goodsIds.map(function(goods_id) {
      return $.ajax({
        type: "post",
        url: "http://localhost:8080/markets/findCartByIds",
        data: "user_id=" + user_id + "&goods_id=" + goods_id,
        success: function(msg) {
          //购物车中的商品数量
          value = msg.data[0].number;
          getGoodsDetailById(goods_id, value);
        }
      });
    });
    Promise.all(promises).then(function() {
      // 所有商品信息获取完毕后，可以执行一些后续操作
      console.log(goodsIds);
    });
}
});

//点击跳转结算界面
$('.cart-floatbar').on('click', '.btn-area', function() {
  $('.cart-item-list .cart-item').each(function(index) {
    if ($(this).hasClass('check-cart-item')) {
      selectIds.push(goodsIds[index]);
      inputValue.push($(this).find('.itxt').val());
   
    }
  });
  for (var i = 0; i < selectIds.length; i++) {
    //更新数量
    $.ajax({
      type: "POST",
      url: "http://localhost:8080/markets/updateCartNumber",
      data: {
        user_id: user_id,
        goods_id: selectIds[i],
        number: inputValue[i]
      },
      success: function(response) {
        console.log(response.data);
        location.href="order.html";
      },
      error: function(error) {
        console.log(response.data);
      }
    });
    //更新状态
    $.ajax({
      type: "POST",
      url: "http://localhost:8080/markets/updateCartStatue",
      data: {
        user_id: user_id,
        goods_id: selectIds[i],
        isChecked: 1,
      },
      success: function(response) {
        console.log(response.data);
        location.href="order.html";
      },
      error: function(error) {
        console.log(response.data);
      }
    });

  }
});

//点击删除商品信息
$('.cart-floatbar').on('click', '.clear-all', function() {
  for (var i = 0; i < goodsIds.length; i++) {
  $.ajax({
    type: "post",
    url: "http://localhost:8080/markets/deleteCart",
    data: "user_id=" + user_id + "&goods_id=" + goodsIds[i],
    success: function(msg) {
    }
  });
}
});

})



function getGoodsDetailById(goods_id, value) {
//detail界面传入的商品id,显示添加成功的图片的介绍
$.ajax({
  type: "post",
  url: "http://localhost:8080/markets/getGoodsById",
  data: "goods_id=" + goods_id
}).then(function(msg) {
  var html = "";
  try {
    //小计的价格
    subtotal = value*msg.data[0].goods_price;
    var html = "<div class='cart-item'>";
    html += "<div class='p-checkbox'>";
    html += "<input type='checkbox' name='' id='' class='j-checkbox'>";
    html += "</div>";
    html += "<div class='p-goods'>";
    html += "<div class='p-img'>";
    html += "<img src='https:" + msg.data[0].image1 + "' style='width:80px;height:80px;'>";
    html += "</div>";
    html += "<div class='p-msg'>"+msg.data[0].goods_name+"</div>";
    html += "</div>";
    html += "<div class='p-price'>￥"+msg.data[0].goods_price+"</div>";
    html += "<div class='p-num'>";
    html += "<div class='quantity-form'>";
    html += "<a href='javascript:;' class='decrement'>-</a>";
    //这里是商品数量
    html += "<input type='text' class='itxt' value='" + value + "'>";
    html += "<a href='javascript:;' class='increment'>+</a>";
    html += "</div>";
    html += "</div>";
    //这里是小计，我先按照一个商品的价格来算
    html += "<div class='p-sum'>￥"+subtotal+"</div>";
    html += "<div class='p-action'><a href='javascript:;'>删除</a></div>";
    html += "</div>";        
  } catch (error) {}
  $(".cart-item-list").append(html);
}); 
}
