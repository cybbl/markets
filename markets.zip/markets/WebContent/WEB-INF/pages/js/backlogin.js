$(function(){
    $(".login").click(function(){    
        var login = $("#username").val();
        var password = $("#password").val();
        if(login=="12"&&password=="12"){
            location.href="backstage.html";
        }    
    
    })
})
