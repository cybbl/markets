var startPage = 1;
var pages = 0;
$(function(){
    //左上角显示
    try {
        var strUser = localStorage.getItem("user");
        var json = JSON.parse(strUser);
        if(json!=null){
            $("#logintop").html(json.username);
            $("#registertop").html("退出登录");
        }    
    } catch (error) {}

    $("#registertop").click(function(){
        localStorage.setItem("user", "");
        location.href = "login.html";
    })

    goodsList(startPage);
    //下方按钮点击翻页跳转
    $(".pn_prevs").click(function(){
        if (startPage == 1) {
            alert("已经是第一页了！");
        } else {
            goodsList(startPage-1);
            startPage = startPage - 1;
        }
    })
    $(".pn_nexts").click(function(){
        if (startPage == pages) {
            alert("已经是最后一页了！");
        } else {
            goodsList(startPage+1);
            startPage = startPage + 1;
        }
    })
    $(".dt").click(function(){
        location.href="index.html";
    })
    
    $(".btn").click(function(){
        var value = $(".text").val();
        $.ajax({
            type:"post",
            url:"http://localhost:8080/markets/findGoodsByName",
            data:"&name=" + value,
            success:function(msg){
                var html = "";
                try {
                    for (var i = 0; i < msg.data.length; i++) {
                        html += "<li class='sk_goods'>";                    
                        html += "<div class='sk_goods_hd'>";
                        //实现点击跳转
                        html += "<a href='detail.html' onclick='storeGoodsId("+msg.data[i].goods_id+")'>";
                        html += "<img width='283' height='290' src="+"https:"+msg.data[i].image1+">";
                        html += "<h5 class='sk_goods_title'>"+msg.data[i].goods_name+"</h5>";
                        html += "<p class='sk_goods_price'>";
                        html += "<em>¥"+msg.data[i].goods_price+"</em>";
                        html +="<div class='sk_goods_progress'>";
                        html += "剩余<em>"+msg.data[i].goods_number+"</em>件";
                        html += "<a href='#' class='sk_goods_buy'>立即抢购</a>";
                    }
                //    var total = msg.page.total; 
                //    if (total % 8 != 0) {
                //     pages = parseInt(total / 8 + 1);
                //     } else {
                //     pages = total / 8;
                //     }
                //     console.log(pages);
                //     //显示页数
                // var htmlStr = "";
                //     for (var i = 1; i <=pages; i++) {
                //         if(i==startPage){
                //             htmlStr+="<a class='current'>"+i+"</a>";
                //         }else{
                //             htmlStr+="<a>"+i+"</a>";
                //         }
                //     }
                } catch (error) {}
                $(".clearfix").html(html);
                //$(".page_num").html(htmlStr);
            }
        })
    })
})

//将商品id传给detail页面
function storeGoodsId(goodsId) {
    localStorage.setItem("goodsId", goodsId);
}

function goodsList(startPage){
    $.ajax({
        type:"post",
        url:"http://localhost:8080/markets/getGoodsList",
        data:"&startPage=" + startPage + "&pageSize=8",
        success:function(msg){
            var html = "";
            try {
                for (var i = 0; i < msg.data.length; i++) {
                    html += "<li class='sk_goods'>";                    
                    html += "<div class='sk_goods_hd'>";
                    //实现点击跳转
                    html += "<a href='detail.html' onclick='storeGoodsId("+msg.data[i].goods_id+")'>";
                    html += "<img width='283' height='290' src="+"https:"+msg.data[i].image1+">";
                    html += "<h5 class='sk_goods_title'>"+msg.data[i].goods_name+"</h5>";
                    html += "<p class='sk_goods_price'>";
                    html += "<em>¥"+msg.data[i].goods_price+"</em>";
                    html +="<div class='sk_goods_progress'>";
                    html += "剩余<em>"+msg.data[i].goods_number+"</em>件";
                    html += "<a href='#' class='sk_goods_buy'>立即抢购</a>";
                }
               var total = msg.page.total; 
               if (total % 8 != 0) {
                pages = parseInt(total / 8 + 1);
                } else {
                pages = total / 8;
                }
                console.log(pages);
                //显示页数
            var htmlStr = "";
                for (var i = 1; i <=pages; i++) {
                    if(i==startPage){
                        htmlStr+="<a class='current'>"+i+"</a>";
                    }else{
                        htmlStr+="<a>"+i+"</a>";
                    }
                }
            } catch (error) {}
            $(".clearfix").html(html);
            $(".page_num").html(htmlStr);
        }
    })
}

  
