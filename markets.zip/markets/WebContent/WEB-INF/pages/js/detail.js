function fun() {
  //放大镜
    $('.preview_img').on('mousemove', function(e) {
      var $small = $(this).find('.small');
      var $mask = $(this).find('.mask');
      var $big = $(this).find('.big');
      var offsetX = e.pageX - $small.offset().left - ($mask.width() / 2);
      var offsetY = e.pageY - $small.offset().top - ($mask.height() / 2);
      var maxX = $small.width() - $mask.width();
      var maxY = $small.height() - $mask.height();
  
      if (offsetX < 0) offsetX = 0;
      if (offsetY < 0) offsetY = 0;
      if (offsetX > maxX) offsetX = maxX;
      if (offsetY > maxY) offsetY = maxY;
  
      $mask.css({
        left: offsetX + 'px',
        top: offsetY + 'px'
      });
  
      var ratioX = $big.children('.bigImg').width() / $small.width();
      var ratioY = $big.children('.bigImg').height() / $small.height();
  
      $big.children('.bigImg').css({
        left: -offsetX * ratioX + 'px',
        top: -offsetY * ratioY + 'px'
      });
    });
  
    $('.preview_img').on('mouseleave', function() {
      $(this).find('.mask').css('left', '-9999px');
    });
  }
  
  
  $(function() {
    //传user,左上角显示
    try {
        var strUser = localStorage.getItem("user");
        var json = JSON.parse(strUser);
        if(json!=null){
            $("#logintop").html(json.username);
            $("#registertop").html("退出登录");
        }    
    } catch (error) {}
    
    $("#registertop").click(function(){
        localStorage.setItem("user", "");
        location.href = "login.html";
    })
    //获取goodId，详情页显示对应的商品全部商品分类
    var goods_id = localStorage.getItem("goodsId");

    $(".addshopcar").click(function(){
        location.href="test.html";
    })
    //显示商品图片
    $.ajax({
      type: "post",
      url: "http://localhost:8080/markets/getGoodsById",
      data: "goods_id=" + goods_id
    }).then(function(msg) {
      var html = "";
      try {
        html += "<div class='preview_img'>";
        html += "<div class='small'>";
        html += "<img src='https:" + msg.data[0].image1 + "' />";
        html += "<div class='mask'></div>";
        html += "</div>";
        html += "<div class='big'>";
        html += "<img src='https:" + msg.data[0].image1+ "' class='bigImg' />";
        html += "</div>";
      } catch (error) {}
      $("#preview_wrap").html(html);
      fun();
    });

    //点击跳转list界面
    $(".dt").click(function(){
        location.href="list.html";
    })
  });
  