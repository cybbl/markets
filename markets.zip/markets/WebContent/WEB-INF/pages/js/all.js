$(function() {
    $("#myOrder").click(function() {
        location.href = "myOrder.html";
    });
    $(".shopcar").click(function(){
        location.href="car.html";
    })

    $(".index").click(function(){
        location.href="index.html";
    })
}); 