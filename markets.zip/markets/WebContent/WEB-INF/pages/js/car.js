var user_id = 0;
$(function() {
    getSum();

        // 全选复选框发生改变时，设置所有商品的复选框状态，并根据全选状态添加或移除选中样式，并计算金额
    $(".checkall").on("change", function() {
        $(".j-checkbox,.checkall").prop("checked", $(this).prop("checked"));
        if ($(this).prop("checked")) {
            $(".cart-item").addClass("check-cart-item");
        } else {
            $(".cart-item").removeClass("check-cart-item");
        };
        getSum();
    });
        // 单个复选框选择
        //商品复选框发生改变时，设置全选复选框状态，并根据商品复选框状态添加或移除选中样式，并计算金额
   $('.cart-item-list').on('change','.j-checkbox', function() {
        if ($(".j-checkbox:checked").length == $(".j-checkbox").length) {
            $(".checkall").prop("checked", true);
        } else {
            $(".checkall").prop("checked", false);
        };
        if ($(this).prop("checked")) {
            $(this).parents(".cart-item").addClass("check-cart-item");
        } else {
            $(this).parents(".cart-item").removeClass("check-cart-item");
        }
        getSum();
    });
        // 增加商品数量
    $('.cart-item-list').on('click', '.increment', function() {
        var num = $(this).siblings(".itxt").val();
        num++;
        $(this).siblings(".itxt").val(num);
        var p = $(this).parents(".p-num").siblings(".p-price").html().substr(1);
        $(this).parents(".p-num").siblings(".p-sum").html("￥" + (p * num).toFixed(2));
        getSum();
    });
        // 减少商品数量

    $('.cart-item-list').on('click', '.decrement', function() {
        var num = $(this).siblings(".itxt").val();
        if (num == 1) {
            return;
        }
        num--;
        $(this).siblings(".itxt").val(num);
        var p = $(this).parents(".p-num").siblings(".p-price").html().substr(1);
        $(this).parents(".p-num").siblings(".p-sum").html("￥" + (p * num).toFixed(2));
        getSum();
    });




        // 手动修改商品数量

    $('.cart-item-list').on('change', '.itxt', function() {
        var num = $(this).val();
        var p = $(this).parents(".p-num").siblings(".p-price").html().substr(1);
        $(this).parents(".p-num").siblings(".p-sum").html("￥" + (p * num).toFixed(2));
        getSum();
    });

    //用户更改数据实时反馈
    function updateCartItemQuantity(goodsId, quantity,user_id) {
        $.ajax({
            url: "http://localhost:8080/markets/updateCartNumber",
            type: "POST",
            data: {
                goods_id: goodsId,
                number: quantity,
                user_id:user_id
            },
            success: function(data) {
                console.log(data);
            },
        });
    }

    // 计算购物车商品数量和金额
    function getSum() {
        var count = 0;
        var money = 0;
        //通过 .itxt 类选中所有的数量输入框，然后通过 .each() 方法遍历每一个数量输入框，
        //对于每个输入框，判断它的父元素 .p-num 的兄弟元素中是否有选中的 .j-checkbox 复选框，
        //如果有，就将该数量输入框中的值解析为整数并加入到 count 中，最终返回选中商品的数量总和 count
        $(".itxt").each(function(index, domEle) {
            if ($(this).parents(".p-num").siblings(".p-checkbox").children(".j-checkbox").prop("checked")) {
                count += parseInt($(domEle).val());
            }
        });
        $(".amount-sum em").text(count);
        //计算金额
        $(".p-sum").each(function(index, domEle) {
            if ($(this).siblings(".p-checkbox").children(".j-checkbox").prop("checked")) {
                money += parseFloat($(domEle).text().substr(1));
            }
        });
        $(".price-sum em").text("￥" + money.toFixed(2));
    };
    //删除购物车里面的一整行
    $('.cart-item-list').on('click', '.p-action', function() {
        $(this).parents(".cart-item").remove();
        getSum();
    });
    //清空购物车
    $(".clear-all").on("click", function() {
        $(".cart-item").remove();
        $(".checkall").prop("checked", false);
        getSum();
    });
    //删除选中的商品
    $(".remove-batch").on("click", function() {
        $(".j-checkbox:checked").parents(".cart-item").remove();
        $(".checkall").prop("checked", false);
        getSum();
    });
})