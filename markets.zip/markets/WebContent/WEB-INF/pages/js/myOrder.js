var user_id =0;
var total = 0;

$(function(){
    try {
        var strUser = localStorage.getItem("user");
        var json = JSON.parse(strUser);
        user_id = json.user_id;
        console.log(user_id)
        if(json!=null){
            $("#logintop").html(json.username);
            $("#registertop").html("退出登录");
        }    
    } catch (error) {}

    $("#registertop").click(function(){
        localStorage.setItem("user", "");
        location.href = "login.html";
    })

    $(".dt").click(function(){
        location.href="list.html";
    })

    
    $.ajax({
        type:"post",
        url:"http://localhost:8080/markets/findOrderCountByUserId",
        data:"user_id="+user_id,
        success:function(msg){
            total = msg;
    $.ajax({
        type:"post",
        url:"http://localhost:8080/markets/findOrderByUserId",
        data:"user_id="+user_id,
        success:function(msg){
            var html="";
            try{
                for(var i =0;i<total;i++){
                var status  = msg.data[i].order_status;
                var orderStatus= (status===1)?"待发货":"未付款";
                var operateStetus = (orderStatus==="待发货")?"提醒发货":"立即支付";
                html +="<div class='choose-title'>";
                html +="<label>";
                html +="<span>　创建日期："+msg.data[i].create_time+"　订单编号："+msg.data[i].order_num+" </span>";
                html +="</label>";
                html +="<a href='#' style='margin-left: 450px'>查看详情</a>";
                html +="</div>";
                html +="<table class='sui-table table-bordered order-datatable'>"
                html +="<tbody>";
                html += "<tr>";
                html += "<td width='35%'>";
                html += "<div class='typographic'>";
                html += "<img src='https:" + msg.data[i].image1 + "' style='width:100px;height:100px;float: left;'>";
                html += "<a href='#' class='block-text'>"+msg.data[i].goods_name+"</a>";
                html += "<span class='guige'></span>";
                html += "</div>";
                html += "</td>";
                html += "<td width='5%' class='center'>";
                html += "<ul class='unstyled'>";
                html += "<li>"+msg.data[i].goods_price+"</li>";
                html += "</ul>";
                html += "</td>";
                html += "<td width='5%' class='center'>"+1+"</td>";
                html += "<td width='8%' class='center'>";
                html += "<a href='#' class=''>再次购买</a><br>";
                html += "</td>";
                html += "<td width='10%' class='center'>";
                html += "<ul class='unstyled'>";
                html += "<li>"+msg.data[i].goods_price+"</li>";
                html += "<li>（含运费：￥0.00）</li>";
                html += "</ul>";
                html += "</td>";
                html += "<td width='10%' class='center'>";
                html += "<ul class='unstyled'>";
                html += "<li>"+orderStatus+"</li>";
                html += "</ul>";
                html += "</td>";
                html += "<td width='10%' class='center'>";
                html += "<ul class='operateStetus' onclick='deliver(\"" + msg.data[i].order_num + "\", " + msg.data[i].order_status + ")'>";
                console.log(msg.data[i].order_num);
                html += "<li>"+operateStetus+"</li>";
                html += "</ul>";
                html += "</td>";
                html += "</tr>";
                html +="</tbody>";
                html +="</table>";
                }                
              }catch(error){}
            $(".orders").append(html);

        }
    })
}
})

})

function deliver(order_num,order_status){
    //如果状态是1就发货，状态是0就更改未发货状态
    if(order_status==1){
        $.ajax({
            type:"post",
            url:"http://localhost:8080/markets/deleteOrderByOrderNumber",
            data:"order_num="+order_num,
            success:function(msg){
                console.log(order_num)
                alert("提醒发货成功");
                location.reload();
            }
        })
    }else{
        var status = 1;
        $.ajax({
            type:"post",
            url:"http://localhost:8080/markets/updateOrderByOrderNumber",
            data:"order_num="+order_num+"&order_status="+status,
            success:function(msg){
                alert("支付成功");
                location.reload();
            }
        })
    }
  
}
