//username判断
$(function(){
    $(".username").mouseleave(function(){
        var username =  $(".username").val();
        if(username==''){
            $(".error").html("请输入用户名");
        }else{
            $.ajax({
                type:"post",
                url:"http://localhost:8080/markets/findByUserName",
                data:"username="+username,
                success:function(msg){
                    if(msg.flag=="success"){
                        $(".error").html("用户名已被注册");
                    }else{
                        $(".error").html('√');
                    }
                }
            })
        }
    })

//email判断
    $(".email").mouseleave(function(){
        var email =  $(".email").val();
        //var username =  $(".username").val();
        var regEmail=/^\w+@\w+(\.[a-zA-Z]{2,3}){1,2}$/;
        if(email==''){
            $(".erroremail").html("请输入邮箱");
        }else if(regEmail.test(email)==false){
            $(".erroremail").html("邮箱格式有误");
        }else{
            $.ajax({
                type:"post",
                url:"http://localhost:8080/markets/findByEmail",
                data:"email="+email,
                success:function(msg){
                    if(msg.flag=="success"){
                        $(".erroremail").html("邮箱已被注册");
                    }else{
                        $(".erroremail").html('√');
                    }
                }
            })
        }
    })

   //phone判断
   $(".phone").mouseleave(function(){
    var phone =  $(".phone").val();
    var regPhone = /^1\d{10}$/;
    if(phone==''){
        $(".errorephone").html("请输入手机号");
    }else if(regPhone.test(phone)==false){
        $(".errorephone").html("手机号格式有误");
    }else{
        $.ajax({
            type:"post",
            url:"http://localhost:8080/markets/findByPhone",
            data:"phone="+phone,
            success:function(msg){
                if(msg.flag=="success"){
                    $(".errorephone").html("手机号已被注册");
                }else{
                    $(".errorephone").html('√');
                }
            }
        })
    }
})
    //password
    $(".password").mouseleave(function(){
        var password =  $(".password").val();
        if(password==''){
            $(".errorpassword").html("请输入密码");
        }else{
            $(".errorpassword").html('√');
        }
    })
    $(".repassword").mouseleave(function(){
        var password =  $(".password").val();
        var repassword =  $(".repassword").val();
        if(password==''){
            $(".errorrepassword").html("请再次输入密码");
        }else if(password!=repassword){
            $(".errorrepassword").html("两次密码输入不一致");
        }else{
            $(".errorrepassword").html('√');
        }
    })

    $(".finish").click(function(){
        var email = $(".email").val();
        var username =  $(".username").val();
        var phone =  $(".phone").val();
        var password =  $(".password").val();
        if(username === '' || email === '' || password === '' || phone === ''){
            return;
        }
        var params = "username=" + username + "&email=" + email + "&password=" + password + "&phone=" + phone;
        $.ajax({
            type: "post",
            url: "http://localhost:8080/markets/addUser",
            data: params,
            success: function(msg) {
                if (msg.flag == "success"&&$(".is7day").is(":checked")) {
                    alert("注册成功，点击确定前往登录界面");
                    location.href = "login.html";
                }else{
                    alert("请勾选用户协议");
                }
            }
        });
    });

    $("#login").click(function(){
        localStorage.setItem("user", "");
        location.href = "login.html";
    })
})
