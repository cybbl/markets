$(function(){
    try {
        var strUser = localStorage.getItem("user");
        var json = JSON.parse(strUser);
        if(json!=null){
            $("#logintop").html(json.username);
            $("#registertop").html("退出登录");
        }    
    } catch (error) {}

    $("#registertop").click(function(){
        localStorage.setItem("user", "");
        location.href = "login.html";
    })

    $(".menu_item").click(function(){
        location.href = "list.html";
    })
})