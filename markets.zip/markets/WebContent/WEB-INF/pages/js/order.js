//用来控制新增地址最先显示
var j = 0;
//用来保存goods_Id
var goodsIds = [];
//记录商品总额
var total = 0;
var address_id = 0;
$(function(){
    //传user,左上角显示
      try {
        var strUser = localStorage.getItem("user");
        var json = JSON.parse(strUser);
        user_id = json.user_id;
        if(json!=null){
            $("#logintop").html(json.username);
            $("#registertop").html("退出登录");
        }    
    } catch (error) {}
    $("#registertop").click(function(){
        localStorage.setItem("user", "");
        location.href = "login.html";
    })
//显示收件人信息
    $.ajax({
        type:"post",
        url:"http://localhost:8080/markets/findAddressByUserId",
        data:"user_id="+user_id,
        success:function(msg){
            var html="";
            address_id = msg.data[0].address_id;
            try{
                html+="<dl>";
                html+="<dt>收件人信息</dt>";
                html+="<dd>";
                html+="<em>"+msg.data[0].realName+"</em>";
                html += "<p>" + msg.data[0].address + "&nbsp;&nbsp;&nbsp;" + msg.data[0].phone + "</p>";
                html+="</dd>";
                html+="</dl>";
                html += "<a href='#' class='add-address-btn' >新增收货地址</a>";
              }catch(error){}
            $(".userinfo.clearfix").html(html);

        }
    })

    //获取商品id
    $.ajax({
      type:"post",
      url:"http://localhost:8080/markets/findAllChecked",
      data:"user_id="+user_id,
      success:function(msg){
        var responseObj = msg.data;
        responseObj.forEach(function(item) {
            goodsIds.push(item.goods_id);
        });       
         //显示商品信息
        for(var i =0;i<goodsIds.length;i++){
        $.ajax({
          type:"post",
          url:"http://localhost:8080/markets/getGoodsById",
          data:"goods_id="+goodsIds[i],
          success:function(msg){
            total+=msg.data[0].goods_price;
            var html = "";
            try {
                html += "<ul>";
                html += "<li class='list-con'>";
                html += "<img src='https:" + msg.data[0].image1 + "' style='width:82px;height:82px;'>";
                html += "<p>"+msg.data[0].goods_name;
                html += "<em>7天无理由退货</em></p>";
                html += "<span class='nub'>";
                html += "<i>￥"+msg.data[0].goods_price+"</i>";
                html += "<strong>X1</strong>";
                html += "<span>有货</span>";
                html += "</span>";
                html += "</li>";
                html += "<ul>";
              } catch (error) {}
              $(".list").append(html);
          }
      })
}
  //商品下面部分显示
  //商品数量和金额
  $.ajax({
    type:"post",
    url:"http://localhost:8080/markets/findAddressByUserId",
    data:"user_id="+user_id,
    success:function(msg){
      var html="";
      try {
          html += '<ul>';
          html += '<li><em>'+ goodsIds.length +'件商品，总商品金额：</em><i>¥'+ total +'</i></li>';
          html += '<li><em>返现：</em><i>-¥0.00</i></li>';
          html += '<li><em>运费：</em><i>¥0.00</i></li>';
          html += '</ul>';
      } catch(error) {}
      $(".total.w").append(html);

      //地址信息显示
      var html="";
      try {
      var html = '<ul>' +
      '<li><p><em>应付总额 ：</em><i>¥'+total+'</i></p></li>' +
      '<li><p>寄送至：'+msg.data[0].address+'  收货人：'+msg.data[0].realName+'  '+msg.data[0].phone+'</p></li>' +
      '</ul>';
      } catch(error) {}
      $(".price.w").append(html);
    }
})
}
})
//点击提交订单,删除购物车信息，新增订单信息
$("#submit").click(function(){
  for(var i =0;i<goodsIds.length;i++){
  //新增订单信息
  var goods_id = goodsIds[i];
  var randomNum = Math.random() * 1000000000000000000; // 生成0到1之间的随机数，并乘以一个合适的倍数
  var order_num = Math.floor(randomNum); // 取整得到长整型数字

  var currentDate = new Date();
  var year = currentDate.getFullYear();
  var month = ('0' + (currentDate.getMonth() + 1)).slice(-2);
  var day = ('0' + currentDate.getDate()).slice(-2);
  var hours = ('0' + currentDate.getHours()).slice(-2);
  var minutes = ('0' + currentDate.getMinutes()).slice(-2);
  var seconds = ('0' + currentDate.getSeconds()).slice(-2);
  var create_time = year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
  $.ajax({
    type: "POST",
    url: "http://localhost:8080/markets/saveOrder",
    data: {
      "order_num": order_num,
      "order_status": "1",
      "order_amount": "1",
      "paid_amount": "1",
      "goods_id": goods_id,
      "buy_counts": "1",
      "create_time": create_time,
      "address_id": address_id
    },
    success: function(response) {
      $.ajax({
        type:"post",
        url:"http://localhost:8080/markets/deleteCart",
        data:"user_id="+user_id+"&goods_id="+goods_id,
        success:function(msg){
          if(i==goodsIds.length){
            alert("支付成功,正在跳转订单界面");
            location.href="myOrder.html";
          }
        }
    })

    }
  });
  



}
})
})


// 为新增收货地址按钮添加点击事件
$(document).on("click", ".add-address-btn", function() {
  // 获取弹窗元素
  var modal = document.getElementById("dialog");

  // 获取关闭弹窗的 <span> 元素
  var closeBtn = document.getElementsByClassName("closeBtn")[0];

   // 获取确定弹窗的 <span> 元素
   var confirmBtn = document.getElementsByClassName("confirmBtn")[0];

  // 当点击按钮时，弹出窗口
  modal.style.display = "block";
  document.body.classList.add("modal-open");

  // 当点击 <span> (x) 按钮时，关闭窗口
  closeBtn.onclick = function() {
      modal.style.display = "none";
      document.body.classList.remove("modal-open");
  }

  confirmBtn.onclick = function() {
    var realName = document.getElementById("receiver").value;
    var address = document.getElementById("address").value;
    var phone = document.getElementById("phone").value;
    $.ajax({
      type:"post",
      url:"http://localhost:8080/markets/addAddress",
      data: "user_id=" + user_id + "&realName=" + realName + "&address=" + address + "&phone=" + phone,
      success:function(msg){
        modal.style.display = "none";
        document.body.classList.remove("modal-open");
        $.ajax({
          type:"post",
          url:"http://localhost:8080/markets/findAddressByUserId",
          data:"user_id="+user_id,
          success:function(msg){
              j++;
              var html="";
              try{
                  html+="<dl>";
                  html+="<dt>收件人信息</dt>";
                  html+="<dd>";
                  //这里新增用户信息
                  html+="<em>"+msg.data[j].realName+"</em>";
                  html += "<p>" + msg.data[j].address + "&nbsp;&nbsp;&nbsp;" + msg.data[j].phone + "</p>";
                  html+="</dd>";
                  html+="</dl>";
                  html += "<a href='#' class='add-address-btn' >新增收货地址</a>";
                }catch(error){}
              $(".userinfo.clearfix").html(html);
              //地址信息显示
                var html="";
                try {
                  var html = '<ul>' +
                  '<li><p><em>应付总额 ：</em><i>¥'+total+'</i></p></li>' +
                  '<li><p>寄送至：'+msg.data[j].address+'  收货人：'+msg.data[j].realName+'  '+msg.data[j].phone+'</p></li>' +
                  '</ul>';
                } catch(error) {}
                $(".price.w").html(html);
                }
      })
    }
})
}
});

  