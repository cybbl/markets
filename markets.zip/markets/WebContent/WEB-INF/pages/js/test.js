var number = 1;
$(function(){
    //传user,左上角显示
  try {
        var strUser = localStorage.getItem("user");
        var json = JSON.parse(strUser);
        if(json!=null){
            $("#logintop").html(json.username);
            $("#registertop").html("退出登录");
        }    
    } catch (error) {}
    $("#registertop").click(function(){
        localStorage.setItem("user", "");
        location.href = "login.html";
    })
    $(".dt").click(function(){
      location.href="list.html";
    })

  //detail界面传入的商品id,显示添加成功的图片的介绍
  var goods_id = localStorage.getItem("goodsId");
  $.ajax({
    type: "post",
    url: "http://localhost:8080/markets/getGoodsById",
    data: "goods_id=" + goods_id
  }).then(function(msg) {
    var html = "";
    try {
      html += "<div class='mid_image'>";
      html += "<img src='https:" + msg.data[0].image1 + "' style='width:77px;height:77px;'>";
      html += "</div>";
      html += "<div class='mid_introduce'>";
      html += "<div class='mid_text'>";
      html += "<p>"+msg.data[0].goods_name+"</p>";
      html += "<div class='mid_num'>";
      html += "<p>数量："+number+"</p>";
      html += "</div></div></div>";
      html += "<div style='clear:both;'></div>";
    } catch (error) {}
    $(".mid_left_bottom").html(html);
  });

  //添加购物车操作
  var user_id = json.user_id;
  //先查看购物车是否存在该商品
  $('.mid').on('click', '.addshopcar2', function() {
  $.ajax({
    type: "post",
    url: "http://localhost:8080/markets/findCartById",
    data: "goods_id=" + goods_id + "&user_id="+user_id,
    success: function(msg) {
      if(msg){
        //查找到就自增数量
        $.ajax({
          type: "post",
          url: "http://localhost:8080/markets/addCartNumber",
          data: "goods_id=" + goods_id+"&user_id="+user_id+"&number="+number,
        success: function(msg) {
          location.href="car.html";
          }
        });
      }else{
        //没查找到就新增商品
        $.ajax({
          type: "post",
          url: "http://localhost:8080/markets/addCart",
          data: "goods_id=" + goods_id+"&user_id="+user_id+"&number="+number,
          success: function(msg) {
            location.href="car.html";
            }
      });
      }
    }
});
})

$('.mid').on('click', '.addshopcar', function() {
  $.ajax({
    type: "post",
    url: "http://localhost:8080/markets/findCartById",
    data: "goods_id=" + goods_id + "&user_id="+user_id,
    success: function(msg) {
      if(msg){
        //查找到就自增数量
        $.ajax({
          type: "post",
          url: "http://localhost:8080/markets/addCartNumber",
          data: "goods_id=" + goods_id+"&user_id="+user_id+"&number="+number,
        success: function(msg) {
          location.href="list.html";
          }
        });
      }else{
        //没查找到就新增商品
        $.ajax({
          type: "post",
          url: "http://localhost:8080/markets/addCart",
          data: "goods_id=" + goods_id+"&user_id="+user_id+"&number="+number,
          success: function(msg) {
            location.href="list.html";
            }
      });
      }
    }
});
})
})
