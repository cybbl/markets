$(function(){
    try {
        var strUser = localStorage.getItem("user");
        var json = JSON.parse(strUser);
        var loginDate = new Date(json.loginDate);
        loginDate = loginDate.setDate(loginDate.getDate() + 7);
        if (new Date() <= loginDate) {
            location.href = "index.html";
        }
    } catch (error) {}
    $("#login").click(function(){
        var username =  $(".username").val();
        var password =  $(".password").val();
        if(username==''){
            $(".error").html("请输入用户名");
        }
        else if(password==''){
            $(".error").html("请输入密码");
        }else{
            $.ajax({
                type:"post",
                url:"http://localhost:8080/markets/login",
                data:"username="+username+"&password="+password,
                success:function(msg){
                    if(msg.flag=="success"){
                    if($("#is7day").is(":checked")){
                        msg.data[0].loginDate = new Date();
                    }
                    localStorage.setItem("user",JSON.stringify(msg.data[0]));
                    location.href = "index.html";
                    }else{
                        $(".error").html(msg.data);
                    }
                }
            })
        }
    })

    $("#register").click(function(){
        location.href = "register.html";
    })
})