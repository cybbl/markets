package cn.zy.dao;

import java.util.HashMap;
import java.util.List;


public interface UserDao {
	//注册页面
	
	public List<HashMap<String, Object>> findByUserName(String username);
	public List<HashMap<String, Object>> findByEmail(String email);
	public List<HashMap<String, Object>> findByPhone(String phone);
	public int addUser(HashMap<String, Object> map);
	
	//登录页面
	public List<HashMap<String, Object>> login(HashMap<String, Object> map);
	public List<HashMap<String, Object>> findAllByUserName(String username);
	public List<HashMap<String, Object>> findAll();
	
	public int findAllCount();
	public int findAllCountByUserName(String username);

}
