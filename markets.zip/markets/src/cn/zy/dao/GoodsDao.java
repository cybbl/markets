package cn.zy.dao;

import java.util.HashMap;
import java.util.List;

public interface GoodsDao {
	public List<HashMap<String, Object>> getGoodsList(HashMap<String, Object> map);
	public List<HashMap<String, Object>> getGoodsListCount(HashMap<String, Object> map);	
	public List<HashMap<String, Object>> getGoodsById(String goods_id);

	public List<HashMap<String, Object>> findGoodsByName(String name);

	public List<HashMap<String, Object>> findGoods();
	public int saveGoods(HashMap<String, Object> map);
}
