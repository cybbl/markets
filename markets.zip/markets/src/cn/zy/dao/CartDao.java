package cn.zy.dao;

import java.util.HashMap;
import java.util.List;

public interface CartDao {
	public List<HashMap<String, Object>> findCartByUserId(String user_Id);
	
	//购物车添加
	public List<HashMap<String, Object>> findCartById(HashMap<String, Object> map);
	public int addCart(HashMap<String, Object> map);
	public int updateCartNumber(HashMap<String, Object> map);
	public int addCartNumber(HashMap<String, Object> map);

	public int deleteCart(HashMap<String, Object> map);
	public int updateCartStatue(HashMap<String, Object> map);

	//购物车显示
	public List<HashMap<String, Object>> findCountByUserId(String user_Id);
	public List<HashMap<String, Object>> findGoodsIdByUserId(String user_Id);
	
	//用户地址
	public List<HashMap<String, Object>> findAddressByUserId(String user_Id);
	public int addAddress(HashMap<String, Object> map);
	public List<HashMap<String, Object>> findAllChecked(String user_id);

	
}	
