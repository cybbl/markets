package cn.zy.dao;

import java.util.HashMap;
import java.util.List;

public interface OrderDao {
	public List<HashMap<String, Object>> findOrderByUserId(String user_id);
	public int findOrderCountByUserId(String user_id);
	public int deleteOrderByOrderNumber(String order_num);
	public int updateOrderByOrderNumber(HashMap<String, Object> map);
	public int saveOrder(HashMap<String, Object> map);

	public List<HashMap<String, Object>> findOrder(HashMap<String, Object> map);
	public List<HashMap<String, Object>> findOrderCount();
	
	public List<HashMap<String, Object>> findOrderByNumberAndName(HashMap<String, Object> map);

}
