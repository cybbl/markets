package cn.zy.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.zy.dao.CartDao;
import cn.zy.pojo.Result;
@Service

public class CartServicelmpl implements CartService {

	@Resource
	CartDao cartDao;
	
	@Override
	public Result findCartByUserId(String user_Id) {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = cartDao.findCartByUserId(user_Id);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;
	}
	@Override
	public boolean findCartById(HashMap<String, Object> map) {
		List<HashMap<String, Object>> list = cartDao.findCartById(map);
		if(list!=null&&list.size()>0) {
			return true;
		}else {
			return false;
		}	
	}
	@Override
	public Result findCartByIds(HashMap<String, Object> map) {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = cartDao.findCartById(map);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}else {
			result.setData("购物车信息不存在");
		}
		return result;
	}
	
	@Override
	public Result addCart(HashMap<String, Object> map) {
		// TODO Auto-generated method stub
		Result result = new Result("fail",null,null);
		//如果已经存在商品和用户信息，就更新总数
		if(findCartById(map)) {
				result.setData("商品信息已存在");
		}else {
			//不存在就添加商品
			int addnumber = cartDao.addCart(map);
			if(addnumber>0) {
				result.setFlag("success");
			}
			
		}
		return result;
	}
	@Override
	public Result deleteCart(HashMap<String, Object> map) {
		// TODO Auto-generated method stub
		Result result = new Result("fail",null,null);
		if(findCartById(map)) {
			int deletenumber= cartDao.deleteCart(map);
			if(deletenumber>0) {
				result.setFlag("success");
				result.setData("删除成功");
			}
		}else {
			result.setData("未找到购物车信息");
		}
		

		return result;
	}
	@Override
	public Result updateCartStatue(HashMap<String, Object> map) {
		Result result = new Result("fail",null,null);
			int updatestatue= cartDao.updateCartStatue(map);
			if(updatestatue>0) {
				result.setFlag("success");
				result.setData("更新成功");
			}
		return result;	

}
	@Override
	public Result updateCartNumber(HashMap<String, Object> map) {
		Result result = new Result("fail",null,null);
		if(findCartById(map)) {
			int updatenumber= cartDao.updateCartNumber(map);
			if(updatenumber>0) {
				result.setFlag("success");
				result.setData("更新成功");
		}
		}else {
			result.setData("未找到购物车信息");
		}
		return result;
	}
	@Override
	public int findCountByUserId(String user_id) {
		// TODO Auto-generated method stub
		List<HashMap<String, Object>> list = cartDao.findCountByUserId(user_id);
		int count = Integer.parseInt(list.get(0).get("count").toString());
		return count;
	}
	@Override
	public Result findGoodsIdByUserId(String user_id) {
		// TODO Auto-generated method stub
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = cartDao.findGoodsIdByUserId(user_id);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;
	}
	@Override
	public Result findAddressByUserId(String user_id) {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = cartDao.findAddressByUserId(user_id);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;

	}
	@Override
	public Result addAddress(HashMap<String, Object> map) {
		Result result = new Result("fail",null,null);
		int addAddress = cartDao.addAddress(map);
		if(addAddress>0) {
			result.setFlag("success");
			result.setData("新增成功");
	}
	return result;
	}
	@Override
	public Result findAllChecked(String user_id) {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = cartDao.findAllChecked(user_id);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;
	}
	@Override
	public Result addCartNumber(HashMap<String, Object> map) {
		Result result = new Result("fail",null,null);
		int addAddress = cartDao.addCartNumber(map);
		if(addAddress>0) {
			result.setFlag("success");
			result.setData("新增数量成功");
	}
	return result;
	}

}
