package cn.zy.service;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.zy.dao.UserDao;
import cn.zy.pojo.Result;
@Service
public class UserServicelmpl implements UserService {
	@Resource
	UserDao userDao;

	@Override
	public Result findByUserName(String username) {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = userDao.findByUserName(username);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
		}
		return result;
	}
	@Override
	public Result findByEmail(String email) {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = userDao.findByEmail(email);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
		}
		return result;
	}
	@Override
	public Result findByPhone(String phone) {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = userDao.findByPhone(phone);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
		}
		return result;
	}
	@Override
	public Result addUser(HashMap<String, Object> map) {
		Result result = new Result("fail",null,null);
		int addUser=userDao.addUser(map);
		if(addUser>0) {
			result.setFlag("success");
		}
		return result;
	}
	@Override
	public Result login(HashMap<String, Object> map) {
		Result result = new Result("fail",null,null);
		String username = map.get("username").toString();
		if(findByUserName(username).getFlag()=="success") {
			List<HashMap<String, Object>> list =userDao.login(map);
			if(list!=null&&list.size()>0) {
				 result.setData(list);
				 result.setFlag("success");
			}else {
				 result.setData("密码错误");
			}		
		}else {
			result.setData("用户名不存在");
			}
		return result;	
	}
	@Override
	public Result findAll() {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = userDao.findAll();
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;
	}
	@Override
	public Result findAllByUserName(String username) {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = userDao.findAllByUserName(username);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;
	}
	@Override
	public int findAllCount() {
		// TODO Auto-generated method stub
		int num = userDao.findAllCount();
		return num;
	}
	@Override
	public int findAllCountByUserName(String username) {
		int num = userDao.findAllCountByUserName(username);
		return num;
	}


}
