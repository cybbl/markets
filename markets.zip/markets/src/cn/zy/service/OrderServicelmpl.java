package cn.zy.service;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.zy.dao.OrderDao;
import cn.zy.pojo.Page;
import cn.zy.pojo.Result;
@Service

public class OrderServicelmpl implements OrderService {
	@Resource
	OrderDao orderDao;
	
	@Override
	public Result findOrderByUserId(String user_id) {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = orderDao.findOrderByUserId(user_id);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;
	}

	@Override
	public int findOrderCountByUserId(String user_id) {
		int total = orderDao.findOrderCountByUserId(user_id);
		return total;
	}

	@Override
	public Result deleteOrderByOrderNumber(String order_num) {
		Result result = new Result("fail",null,null);
		int num = orderDao.deleteOrderByOrderNumber(order_num);
		if(num>0) {
			result.setFlag("success");
		}
		return result;
	}

	@Override
	public Result updateOrderByOrderNumber(HashMap<String, Object> map) {
		Result result = new Result("fail",null,null);
		int num = orderDao.updateOrderByOrderNumber(map);
		if(num>0) {
			result.setFlag("success");
		}
		return result;
	}

	@Override
	public Result saveOrder(HashMap<String, Object> map) {
		Result result = new Result("fail",null,null);
		int num = orderDao.saveOrder(map);
		if(num>0) {
			result.setFlag("success");
		}
		return result;
	}

	@Override
	public Result findOrder(HashMap<String, Object> map) {
		int startPage = Integer.parseInt(map.get("start").toString());
		int pageSize = Integer.parseInt(map.get("pageSize").toString());
		int total=0;
		List<HashMap<String, Object>> list = orderDao.findOrder(map);
		List<HashMap<String, Object>> listCount =orderDao.findOrderCount();
		total = Integer.parseInt(listCount.get(0).get("total").toString());
		
		Page page = new Page(startPage,pageSize,total);
		Result result = new Result("success",list,page);
		return result;
	}

	@Override
	public Result findOrderByNumberAndName(HashMap<String, Object> map) {
		Result result = new Result("fail",null,null);
		List<HashMap<String, Object>> list = orderDao.findOrderByNumberAndName(map);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;
	}


}
