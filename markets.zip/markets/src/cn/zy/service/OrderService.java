package cn.zy.service;

import java.util.HashMap;
import java.util.List;

import cn.zy.pojo.Result;

public interface OrderService {
	public Result findOrderByUserId (String user_id);
	public int findOrderCountByUserId (String user_id);
	public Result deleteOrderByOrderNumber(String order_num);
	public Result updateOrderByOrderNumber(HashMap<String, Object> map);
	public Result saveOrder(HashMap<String, Object> map);

	public Result findOrder (HashMap<String, Object> map);
	public Result findOrderByNumberAndName(HashMap<String, Object> map);

	
}
