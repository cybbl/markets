package cn.zy.service;

import java.util.HashMap;

import cn.zy.pojo.Result;

public interface GoodsService {
	public Result getGoodsList(HashMap<String, Object> map);
	public Result getGoodsById(String goods_id);

	public Result findGoodsByName(String name);
	
	public Result findGoods();
	public Result saveGoods(HashMap<String, Object> map);


}
