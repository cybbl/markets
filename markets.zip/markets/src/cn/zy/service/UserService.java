package cn.zy.service;

import java.util.HashMap;

import cn.zy.pojo.Result;

public interface UserService {
	public Result findByUserName(String username);
	public Result findByEmail(String email);
	public Result findByPhone(String phone);
	public Result addUser(HashMap<String, Object> map);

	public Result login(HashMap<String, Object> map);
	
	public Result findAll();
	public Result findAllByUserName(String username);
	
	public int findAllCount();
	public int findAllCountByUserName(String username);

}
