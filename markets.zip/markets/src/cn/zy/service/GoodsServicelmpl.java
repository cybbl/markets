package cn.zy.service;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.zy.dao.GoodsDao;
import cn.zy.pojo.Result;
import cn.zy.pojo.Page;
@Service
public class GoodsServicelmpl implements GoodsService {
	@Resource
	GoodsDao goodsDao;
	
	Result result = new Result("fail",null,null);
	@Override
	public Result getGoodsList(HashMap<String, Object> map) {
		int startPage = Integer.parseInt(map.get("start").toString());
		int pageSize = Integer.parseInt(map.get("pageSize").toString());
		int total=0;
		List<HashMap<String, Object>> list = goodsDao.getGoodsList(map);
		List<HashMap<String, Object>> listCount = goodsDao.getGoodsListCount(map);
		total = Integer.parseInt(listCount.get(0).get("total").toString());
		
		Page page = new Page(startPage,pageSize,total);
		Result result = new Result("success",list,page);
		return result;
	}
	@Override
	public Result getGoodsById(String goods_id) {
		List<HashMap<String, Object>> list = goodsDao.getGoodsById(goods_id);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;
	}
	@Override
	public Result findGoodsByName(String name) {
		List<HashMap<String, Object>> list = goodsDao.findGoodsByName(name);
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;
	}
	@Override
	public Result findGoods() {
		List<HashMap<String, Object>> list = goodsDao.findGoods();
		if(list!=null&&list.size()>0) {
			result.setFlag("success");
			result.setData(list);
		}
		return result;
	}
	@Override
	public Result saveGoods(HashMap<String, Object> map) {
		int num  = goodsDao.saveGoods(map);
		if(num>0) {
			result.setFlag("success");
		}
		return result;
	}

}
