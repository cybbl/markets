package cn.zy.service;

import java.util.HashMap;

import cn.zy.pojo.Result;

public interface CartService {
	public Result findCartByUserId (String user_Id);
	
	public boolean findCartById(HashMap<String, Object> map);
	public Result findCartByIds(HashMap<String, Object> map);
	public Result addCart(HashMap<String, Object> map);
	public Result updateCartNumber(HashMap<String, Object> map);
	public Result addCartNumber(HashMap<String, Object> map);

	public Result deleteCart(HashMap<String, Object> map);
	public Result updateCartStatue(HashMap<String, Object> map);
	
	public int findCountByUserId(String user_Id);
	public Result findGoodsIdByUserId(String user_Id);

	
	public Result findAddressByUserId(String user_Id);
	public Result addAddress(HashMap<String, Object> map);
	public Result findAllChecked(String user_id);

}
