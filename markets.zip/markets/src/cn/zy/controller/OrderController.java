package cn.zy.controller;

import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.zy.service.OrderService;

@Controller

public class OrderController {
	@Resource
	OrderService orderService;
	
	@RequestMapping("/findOrderByUserId")
	@ResponseBody
	public Object findOrderByUserId(String user_id) {
		return orderService.findOrderByUserId(user_id);
	}
	
	@RequestMapping("/findOrderCountByUserId")
	@ResponseBody
	public Object findOrderCountByUserId(String user_id) {
		return orderService.findOrderCountByUserId(user_id);
	}
	
	@RequestMapping("/deleteOrderByOrderNumber")
	@ResponseBody
	public Object deleteOrderByOrderNumber(String order_num) {
		return orderService.deleteOrderByOrderNumber(order_num);
	}
	
	@RequestMapping("/updateOrderByOrderNumber")
	@ResponseBody
	public Object updateOrderByOrderNumber(String order_num,String order_status) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("order_num", order_num);
		map.put("order_status", order_status);
		return orderService.updateOrderByOrderNumber(map);
	}
	
	@RequestMapping("/saveOrder")
	@ResponseBody
	public Object saveOrder(String order_num,String order_status,String order_amount,String paid_amount,String goods_id,String buy_counts,String create_time,String address_id) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("order_num", order_num);
		map.put("order_status", order_status);
		map.put("order_amount", order_amount);
		map.put("paid_amount", paid_amount);
		map.put("goods_id", goods_id);
		map.put("buy_counts", buy_counts);
		map.put("create_time", create_time);
		map.put("address_id", address_id);

		return orderService.saveOrder(map);
	}
	
	@RequestMapping("/findOrder")
	@ResponseBody
	public Object findOrder(int startPage,int pageSize) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("startPage", (startPage - 1) * pageSize);
		map.put("pageSize", pageSize);
		map.put("start", startPage);
		return orderService.findOrder(map);
	}
	
	@RequestMapping("/findOrderByNumberAndName")
	@ResponseBody
	public Object findOrderByNumberAndName(String order_num,String realName) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("order_num", order_num);
		map.put("realName", realName);
		return orderService.findOrderByNumberAndName(map);
	}
	
}
