package cn.zy.controller;

import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.zy.service.UserService;

@Controller
public class UserController {
	@Resource
	UserService userService;
	
	@RequestMapping("/findByUserName")
	@ResponseBody
	public Object findByUserName(String username) {
		return userService.findByUserName(username);
	}
	@RequestMapping("/findByEmail")
	@ResponseBody
	public Object findByEmail(String email) {
		return userService.findByEmail(email);
	}
	@RequestMapping("/findByPhone")
	@ResponseBody
	public Object findByPhone(String phone) {
		return userService.findByPhone(phone);
	}
	@RequestMapping("/addUser")
	@ResponseBody
	public Object addUser(String username,String email,String phone,String password) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("email", email);
		map.put("username", username);
		map.put("phone", phone);
		map.put("password", password);
		return userService.addUser(map);
	}
	
	@RequestMapping("/login")
	@ResponseBody
	public Object login(String username,String password) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("username", username);
		map.put("password", password); 
		return userService.login(map);
	}
	
	@RequestMapping("/findAll")
	@ResponseBody
	public Object findAll() {
		return userService.findAll();
	}
	
	@RequestMapping("/findAllByUserName")
	@ResponseBody
	public Object findAllByUserName(String username) {
		return userService.findAllByUserName(username);
	}
	
	@RequestMapping("/findAllCount")
	@ResponseBody
	public Object findAllCount() {
		return userService.findAllCount();
	}
	
	@RequestMapping("/findAllCountByUserName")
	@ResponseBody
	public Object findAllCountByUserName(String username) {
		return userService.findAllCountByUserName(username);
	}
}
