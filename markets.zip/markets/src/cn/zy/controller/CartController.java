package cn.zy.controller;

import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.zy.service.CartService;

@Controller
public class CartController {
	@Resource
	CartService cartService;
	
	@RequestMapping("/findCartByUserId")
	@ResponseBody
	public Object findCartByUserId(String user_id) {
		return cartService.findCartByUserId(user_id);
	}
	
	@RequestMapping("/findCartById")
	@ResponseBody
	public Object findCartById(String user_id,String goods_id) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("user_id", user_id);
		map.put("goods_id", goods_id);
		return cartService.findCartById(map);
	}
	
	@RequestMapping("/findCartByIds")
	@ResponseBody
	public Object findCartByIds(String user_id,String goods_id) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("user_id", user_id);
		map.put("goods_id", goods_id);
		return cartService.findCartByIds(map);
	}
	
	@RequestMapping("/addCart")
	@ResponseBody
	public Object addCart(String user_id,String goods_id,int number) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("user_id", user_id);
		map.put("goods_id", goods_id);
		map.put("number", number);
		return cartService.addCart(map);
	}
		
	@RequestMapping("/updateCartNumber")
	@ResponseBody
	public Object updateCartNumber(String goods_id,String user_id,int number) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("goods_id", goods_id);
		map.put("number", number);
		map.put("user_id", user_id);
		return cartService.updateCartNumber(map);
	}
	
	@RequestMapping("/deleteCart")
	@ResponseBody
	public Object deleteCart(String user_id,String goods_id) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("goods_id", goods_id);
		map.put("user_id", user_id);
		return cartService.deleteCart(map);
	}

	@RequestMapping("/updateCartStatue")
	@ResponseBody
	public Object updateCartStatue(String goods_id,String isChecked,String user_id) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("goods_id", goods_id);
		map.put("isChecked", isChecked);
		map.put("user_id", user_id);

		return cartService.updateCartStatue(map);
	}
	
	@RequestMapping("/findCountByUserId")
	@ResponseBody
	public Object findCountByUserId(String user_id) {
		return cartService.findCountByUserId(user_id);
	}
	
	@RequestMapping("/findGoodsIdByUserId")
	@ResponseBody
	public Object findGoodsIdByUserId(String user_id) {
		return cartService.findGoodsIdByUserId(user_id);
	}
	
	@RequestMapping("/findAddressByUserId")
	@ResponseBody
	public Object findAddressByUserId(String user_id) {
		return cartService.findAddressByUserId(user_id);
	}
	
	@RequestMapping("/addAddress")
	@ResponseBody
	public Object addAddress(String user_id,String realName,String address,String phone) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("user_id", user_id);
		map.put("realName", realName);
		map.put("address", address);
		map.put("phone", phone);
		return cartService.addAddress(map);
	}
	
	@RequestMapping("/findAllChecked")
	@ResponseBody
	public Object findAllChecked(String user_id) {
		return cartService.findAllChecked(user_id);
	}
	
	@RequestMapping("/addCartNumber")
	@ResponseBody
	public Object addAddress(String user_id,String goods_id,String number) {
		HashMap<String, Object> map = new HashMap<>();
		map.put("user_id", user_id);
		map.put("goods_id", goods_id);
		map.put("number", number);
		return cartService.addCartNumber(map);
	}
}
