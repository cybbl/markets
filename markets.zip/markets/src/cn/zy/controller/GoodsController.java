package cn.zy.controller;

import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.zy.service.GoodsService;

@Controller
public class GoodsController {
	@Resource
	GoodsService goodsService;
	
	@RequestMapping("/getGoodsList")
	@ResponseBody
	public Object getGoodsList(int startPage,int pageSize) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("startPage", (startPage - 1) * pageSize);
		map.put("pageSize", pageSize);
		map.put("start", startPage);
		return goodsService.getGoodsList(map);
	}
	@RequestMapping("/getGoodsById")
	@ResponseBody
	public Object getGoodsById(String goods_id) {
		return goodsService.getGoodsById(goods_id);
	}

	@RequestMapping("/findGoodsByName")
	@ResponseBody
	public Object findGoodsByName(String name) {
		return goodsService.findGoodsByName(name);
	}
	
	@RequestMapping("/findGoods")
	@ResponseBody
	public Object findGoods() {
		return goodsService.findGoods();
	}
	
	@RequestMapping("/saveGoods")
	@ResponseBody
	public Object saveGoods(String goods_id,String goods_name,String cat_id,String image1,
			String image2,String image3,String image4,String image5,
			String goods_price,String goods_number,String goods_introduce) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("goods_id", goods_id);
		map.put("goods_name", goods_name);
		map.put("cat_id", cat_id);
		map.put("image1", image1);
		map.put("image2", image2);
		map.put("image3", image3);
		map.put("image4", image4);
		map.put("image5", image5);
		map.put("goods_price", goods_price);
		map.put("goods_number", goods_number);
		map.put("goods_introduce", goods_introduce);
		return goodsService.saveGoods(map);
	}

}










